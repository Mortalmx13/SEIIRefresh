from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
driver.get('http://localhost:5173/')

# Login
try:
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, ":r0:-form-item"))).send_keys(user['email'])
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, ":r1:-form-item"))).send_keys(user['password'] + Keys.ENTER)
    print("Login successful.")
except Exception as e:
    print("Login failed:", e)

# Navigate to Create Post
try:
    WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Create Post"))).click()
    print("Navigated to Create Post page.")
except Exception as e:
    print("Navigation to Create Post page failed:", e)

# Fill post details
try:
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "location"))).send_keys("Test Drink")
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "caption"))).send_keys("This is a test to place Ingredients")
    # Uncomment and adjust the file upload part if necessary
    # file_input = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "cursor-pointer")))
    # file_input.send_keys(file_path)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "tags"))).send_keys("Drink, Test" + Keys.ENTER)
    print("Post details filled successfully.")
except Exception as e:
    print("Filling post details failed:", e)

# Wait for post creation to complete or validate it
try:
    WebDriverWait(driver, 10).until(EC.text_to_be_present_in_element((By.TAG_NAME, "body"), "Post created successfully"))
    print("Post creation confirmed.")
except Exception as e:
    print("Post creation failed to confirm:", e)

# Cleanup and close
driver.quit()
print("Test completed and browser closed.")
