import FormLogin from "../Components/formlogin"

export default function Login(){
    return(
        <div>
            <FormLogin />
        </div>
    )
}