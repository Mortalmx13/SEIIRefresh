import FormSignup from "../Components/formsignup"

export default function Register(){
    return(
        <div>
            <FormSignup />
        </div>
    )
}