import React from 'react'

const AllUsers = () => {
  return (
    <div>AllUsers</div>
  )
}

export default AllUsers