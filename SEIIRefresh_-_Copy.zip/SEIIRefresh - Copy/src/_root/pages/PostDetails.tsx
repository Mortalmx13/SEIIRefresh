import React from 'react'

const PostDetails = () => {
  return (
    <div>PostDetails</div>
  )
}

export default PostDetails