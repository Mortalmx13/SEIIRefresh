import React from 'react'

const EditPost = () => {
  return (
    <div>EditPost</div>
  )
}

export default EditPost