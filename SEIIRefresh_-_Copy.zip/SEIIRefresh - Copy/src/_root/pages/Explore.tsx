import React from 'react'

const Explore = () => {
  return (
    <div>Explore</div>
  )
}

export default Explore